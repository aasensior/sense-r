#' An Hello Wolrd function
#' 
#' This is just a sample of an hello wolrd function to say hi!
#' @keywords hello
#' @export
#' @examples
#' hello_function()
hello_function <- function() {
  print("Hello, world!")
}